# AR Sales — Fundação Supabase

Primeira migration do SaaS multiempresa da AR Softwares.

## Incluído

- Perfis integrados ao Supabase Auth
- Empresas/workspaces
- Usuários vinculados a várias empresas
- Cargos e permissões por empresa
- Clientes, contatos e endereços
- Produtos, categorias e mídia
- Tabelas de preços
- Modelos de orçamento
- Orçamentos e itens
- Cálculo automático dos totais
- Índices iniciais
- Row Level Security (RLS)
- Criação automática dos cargos Administrador e Vendedor

## Como aplicar

1. Crie um projeto no Supabase.
2. Abra **SQL Editor**.
3. Execute o arquivo:

```text
supabase/migrations/20260710_001_initial_schema.sql
```

Também pode ser aplicado com Supabase CLI:

```bash
supabase db push
```

## Observações importantes

- O sistema usa `company_id` para isolamento multiempresa.
- A RLS valida o vínculo do usuário em `company_members`.
- A empresa criada recebe automaticamente os cargos Administrador e Vendedor.
- O proprietário entra automaticamente como membro Administrador.
- Exclusão lógica está preparada com `deleted_at`.
- As tabelas principais possuem `version`, `updated_at` ou ambos para futura sincronização offline.

## Próxima migration sugerida

- CRM e pipeline
- Agenda e visitas
- Numeração automática de orçamentos
- Auditoria
- Storage policies para logos, produtos e anexos
- Funções RPC para criação segura de empresa e convites
